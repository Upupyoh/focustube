import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'focustube_browser_screen.dart';
import 'channel_blocker_screen.dart';

class AppRestrictionsScreen extends StatefulWidget {
  const AppRestrictionsScreen({Key? key}) : super(key: key);

  @override
  State<AppRestrictionsScreen> createState() => _AppRestrictionsScreenState();
}

class _AppRestrictionsScreenState extends State<AppRestrictionsScreen> {
  int _selectedTab = 0;
  bool _internetAccess = true;
  bool _includeInScreenUsage = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgMain,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: AppTheme.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // YouTube App Header
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF0000),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.red.withOpacity(0.35),
                        blurRadius: 18,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'com.google.android.youtube',
                  style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 2),
                const Text(
                  'YouTube',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 16),

                // Pill Tab Switcher
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF171927),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildTabPill(
                          label: '📄 Screen',
                          isSelected: _selectedTab == 0,
                          onTap: () => setState(() => _selectedTab = 0),
                        ),
                      ),
                      Expanded(
                        child: _buildTabPill(
                          label: '🌐 Data',
                          isSelected: _selectedTab == 1,
                          onTap: () => setState(() => _selectedTab = 1),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Screen Time Mini Chart
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withOpacity(0.04)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.phone_android_rounded, color: AppTheme.accentPurpleLight, size: 20),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text('Screen time', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
                              Text(
                                '36 minutes',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        height: 90,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            _buildMiniBar('Mon', 0.45, false),
                            _buildMiniBar('Tue', 0.85, true),
                            _buildMiniBar('Wed', 0.0, false),
                            _buildMiniBar('Thu', 0.0, false),
                            _buildMiniBar('Fri', 0.0, false),
                            _buildMiniBar('Sat', 0.0, false),
                            _buildMiniBar('Sun', 0.0, false),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                // Restrictions Section Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      'Restrictions',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
                    ),
                    Text(
                      'November 25, 2026',
                      style: TextStyle(fontSize: 11, color: AppTheme.textMuted),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                _buildConfigItem(
                  icon: Icons.timer_outlined,
                  title: 'App timer',
                  subtitle: 'Not set',
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.rocket_launch_outlined,
                  title: 'Launch limit',
                  subtitle: 'Launched 0 times today.',
                  trailingText: 'Not set',
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.coffee_rounded,
                  title: 'Active period',
                  subtitle: 'Not set',
                  trailingIcon: Icons.keyboard_arrow_down_rounded,
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.public_rounded,
                  title: 'Internet access',
                  subtitle: "Switch off to block app's internet.",
                  trailingWidget: Switch(
                    value: _internetAccess,
                    activeColor: AppTheme.accentPurple,
                    onChanged: (val) => setState(() => _internetAccess = val),
                  ),
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.crop_square_rounded,
                  title: 'Restriction groups',
                  subtitle: 'Not set',
                  trailingIcon: Icons.chevron_right_rounded,
                ),
                const SizedBox(height: 8),

                // Custom FocusTube Content Filter Shortcut
                _buildConfigItem(
                  icon: Icons.shield_outlined,
                  title: 'Channel & Thumbnail Shielding',
                  subtitle: 'Active YouTube content rules & auto-blur.',
                  trailingIcon: Icons.chevron_right_rounded,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ChannelBlockerScreen()),
                    );
                  },
                ),
                const SizedBox(height: 24),

                // Quick Actions
                const Text(
                  'Quick actions',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
                ),
                const SizedBox(height: 10),

                _buildConfigItem(
                  icon: Icons.open_in_new_rounded,
                  title: 'Launch app',
                  subtitle: 'Open YouTube with FocusTube protection active.',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const FocusTubeBrowserScreen()),
                    );
                  },
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.settings_outlined,
                  title: 'Go to app settings',
                  subtitle: 'Manage app settings like notifications, permissions, storage and more.',
                ),
                const SizedBox(height: 8),

                _buildConfigItem(
                  icon: Icons.phone_android_rounded,
                  title: 'Include in screen usage',
                  subtitle: 'Switch off to exclude this app from total screen usage.',
                  trailingWidget: Switch(
                    value: _includeInScreenUsage,
                    activeColor: AppTheme.accentPurple,
                    onChanged: (val) => setState(() => _includeInScreenUsage = val),
                  ),
                ),
              ],
            ),
          ),

          // Sticky Bottom Emergency Pass Button
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.bgMain.withOpacity(0.0),
                    AppTheme.bgMain.withOpacity(0.95),
                    AppTheme.bgMain,
                  ],
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('🔥 Emergency Pass activated! YouTube unblocked for 5 minutes.'),
                          backgroundColor: AppTheme.accentPurple,
                        ),
                      );
                    },
                    icon: const Icon(Icons.local_fire_department_rounded, color: Color(0xFF171A28), size: 18),
                    label: const Text(
                      'Emergency',
                      style: TextStyle(color: Color(0xFF171A28), fontWeight: FontWeight.bold),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFC7CBFA),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabPill({required String label, required bool isSelected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF2B2F48) : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: isSelected ? AppTheme.textPrimary : AppTheme.textSecondary,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMiniBar(String day, double heightFraction, bool isHighlighted) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 12,
          height: 60 * heightFraction + (heightFraction > 0 ? 4 : 2),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isHighlighted
                  ? [const Color(0xFFB0A4FF), const Color(0xFF5D50C7)]
                  : [const Color(0xFF9182F7), const Color(0xFF3E3875)],
            ),
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        const SizedBox(height: 6),
        Text(day, style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
      ],
    );
  }

  Widget _buildConfigItem({
    required IconData icon,
    required String title,
    required String subtitle,
    String? trailingText,
    IconData? trailingIcon,
    Widget? trailingWidget,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.03)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppTheme.textSecondary),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 11.5, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            if (trailingText != null)
              Text(
                trailingText,
                style: const TextStyle(fontSize: 12, color: AppTheme.textMuted),
              ),
            if (trailingWidget != null) trailingWidget,
            if (trailingIcon != null) Icon(trailingIcon, color: AppTheme.textMuted, size: 18),
          ],
        ),
      ),
    );
  }
}
