import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/filter_service.dart';
import '../theme/app_theme.dart';

class ChannelBlockerScreen extends StatefulWidget {
  const ChannelBlockerScreen({Key? key}) : super(key: key);

  @override
  State<ChannelBlockerScreen> createState() => _ChannelBlockerScreenState();
}

class _ChannelBlockerScreenState extends State<ChannelBlockerScreen> {
  final TextEditingController _channelController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();

  @override
  void dispose() {
    _channelController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  void _addChannel(FilterService filterService) {
    final name = _channelController.text.trim();
    final reason = _reasonController.text.trim().isEmpty ? 'User Blocked' : _reasonController.text.trim();
    if (name.isNotEmpty) {
      filterService.addBlockedChannel(name, reason: reason);
      _channelController.clear();
      _reasonController.clear();
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filterService = Provider.of<FilterService>(context);

    return Scaffold(
      backgroundColor: AppTheme.bgMain,
      appBar: AppBar(
        title: const Text('Channel & Category Blocker', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: AppTheme.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Info Header Banner
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.accentPurple.withOpacity(0.2)),
              ),
              child: Row(
                children: const [
                  Icon(Icons.shield_rounded, color: AppTheme.accentPurpleLight, size: 28),
                  SizedBox(width: 14),
                  Expanded(
                    child: Text(
                      'এখানে যুক্ত করা চ্যানেলগুলো ইউটিউব ফিডে কখনোই প্রদর্শিত হবে না। একই ডিভাইস অন্য কেউ ব্যবহার করলেও এই চ্যানেলগুলো সম্পূর্ণ লুকানো থাকবে।',
                      style: TextStyle(fontSize: 12.5, color: AppTheme.textSecondary, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),

            // Block Channel Button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'ব্লক করা চ্যানেল তালিকা',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
                ),
                TextButton.icon(
                  onPressed: () => _showAddChannelDialog(context, filterService),
                  icon: const Icon(Icons.add, size: 16, color: AppTheme.accentPurpleLight),
                  label: const Text('চ্যানেল যোগ করুন', style: TextStyle(color: AppTheme.accentPurpleLight, fontSize: 13)),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Blocked Channels List
            if (filterService.blockedChannels.isEmpty)
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text('কোনো চ্যানেল এখনো ব্লক করা হয়নি।', style: TextStyle(color: AppTheme.textMuted, fontSize: 13)),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filterService.blockedChannels.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (ctx, idx) {
                  final ch = filterService.blockedChannels[idx];
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.03)),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.red.withOpacity(0.15),
                          child: const Icon(Icons.block_rounded, size: 18, color: Colors.redAccent),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(ch.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5, color: AppTheme.textPrimary)),
                              const SizedBox(height: 2),
                              Text(ch.reason, style: const TextStyle(fontSize: 11.5, color: AppTheme.textSecondary)),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: AppTheme.textMuted, size: 20),
                          onPressed: () => filterService.removeBlockedChannel(ch.id),
                        ),
                      ],
                    ),
                  );
                },
              ),

            const SizedBox(height: 26),

            // Category Filter Rules Section
            const Text(
              'স্মার্ট ক্যাটাগরি শিল্ডিং (Smart Categories)',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
            ),
            const SizedBox(height: 10),

            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filterService.categoryRules.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, idx) {
                final rule = filterService.categoryRules[idx];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.03)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(rule.categoryName, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.textPrimary)),
                            const SizedBox(height: 3),
                            Text(
                              'কিওয়ার্ড: ${rule.keywords.take(3).join(', ')}...',
                              style: const TextStyle(fontSize: 11.5, color: AppTheme.textSecondary),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: rule.isEnabled,
                        activeColor: AppTheme.accentPurple,
                        onChanged: (val) {
                          filterService.toggleCategoryRule(rule.id, val);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showAddChannelDialog(BuildContext context, FilterService filterService) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.bgCardElevated,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            left: 20,
            right: 20,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('🚫 চ্যানেল ব্লক করুন', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(
                controller: _channelController,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'ইউটিউব চ্যানেলের নাম লিখুন (যেমন: Drama Daily)',
                  hintStyle: const TextStyle(color: AppTheme.textMuted, fontSize: 13),
                  filled: true,
                  fillColor: AppTheme.bgMain,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _reasonController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'ব্লক করার কারণ (অপশনাল)',
                  hintStyle: const TextStyle(color: AppTheme.textMuted, fontSize: 13),
                  filled: true,
                  fillColor: AppTheme.bgMain,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => _addChannel(filterService),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accentPurple,
                  minimumSize: const Size.fromHeight(48),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('ব্লক নিশ্চিত করুন', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ],
          ),
        );
      },
    );
  }
}
