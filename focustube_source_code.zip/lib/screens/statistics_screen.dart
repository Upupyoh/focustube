import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/filter_models.dart';
import 'app_restrictions_screen.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({Key? key}) : super(key: key);

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  int _selectedTab = 0; // 0 = Screen, 1 = Data

  final List<AppUsageItem> _appsList = [
    AppUsageItem(appName: 'YouTube', packageName: 'com.google.android.youtube', usageMinutes: 36, iconKey: 'yt'),
    AppUsageItem(appName: 'Settings', packageName: 'com.android.settings', usageMinutes: 10, iconKey: 'settings'),
    AppUsageItem(appName: 'Contacts', packageName: 'com.google.android.contacts', usageMinutes: 4, iconKey: 'contacts'),
    AppUsageItem(appName: 'Play Store', packageName: 'com.android.vending', usageMinutes: 2, iconKey: 'playstore'),
    AppUsageItem(appName: 'WO Mic', packageName: 'com.wireless.orange.xmic', usageMinutes: 2, iconKey: 'mic'),
    AppUsageItem(appName: 'Snaptube', packageName: 'com.snaptube.premium', usageMinutes: 2, iconKey: 'snaptube'),
    AppUsageItem(appName: 'Mindful', packageName: 'com.mindful.app', usageMinutes: 2, iconKey: 'mindful'),
    AppUsageItem(appName: 'Chrome', packageName: 'com.android.chrome', usageMinutes: 1, iconKey: 'chrome'),
    AppUsageItem(appName: 'Gmail', packageName: 'com.google.android.gm', usageMinutes: 1, iconKey: 'gmail'),
    AppUsageItem(appName: 'MovieBox+', packageName: 'com.moviebox.plus', usageMinutes: 1, iconKey: 'moviebox'),
    AppUsageItem(appName: 'PLAYit', packageName: 'com.playit.videoplayer', usageMinutes: 0, usageSeconds: 15, iconKey: 'playit'),
    AppUsageItem(appName: 'Messages', packageName: 'com.google.android.apps.messaging', usageMinutes: 0, usageSeconds: 13, iconKey: 'messages'),
    AppUsageItem(appName: 'Google', packageName: 'com.google.android.googlequicksearchbox', usageMinutes: 0, usageSeconds: 8, iconKey: 'google'),
    AppUsageItem(appName: 'Phone', packageName: 'com.google.android.dialer', usageMinutes: 0, usageSeconds: 2, iconKey: 'phone'),
    AppUsageItem(appName: 'Calendar', packageName: 'com.google.android.calendar', usageMinutes: 0, usageSeconds: 1, iconKey: 'calendar'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgMain,
      appBar: AppBar(
        title: const Text(
          'Statistics',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: AppTheme.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Pill Tab Switcher (Screen / Data)
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFF171927),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.borderSubtle),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _buildTabPill(
                      label: '📄 Screen',
                      isSelected: _selectedTab == 0,
                      onTap: () => setState(() => _selectedTab = 0),
                    ),
                  ),
                  Expanded(
                    child: _buildTabPill(
                      label: '🌐 Data',
                      isSelected: _selectedTab == 1,
                      onTap: () => setState(() => _selectedTab = 1),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Screen Time Card with Bar Chart
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.04)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.accentPurpleBg,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.phone_android_rounded, color: AppTheme.accentPurpleLight, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Screen time', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                          SizedBox(height: 2),
                          Text(
                            '1 hour, 5 minutes',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Weekly Bars
                  SizedBox(
                    height: 130,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _buildBar('Mon', 0.35, false),
                        _buildBar('Tue', 0.90, false),
                        _buildBar('Wed', 0.40, true),
                        _buildBar('Thu', 0.0, false),
                        _buildBar('Fri', 0.0, false),
                        _buildBar('Sat', 0.0, false),
                        _buildBar('Sun', 0.0, false),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Date Navigator
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Icon(Icons.chevron_left_rounded, color: AppTheme.textMuted, size: 20),
                      Text('Nov 23 - Nov 29', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      Icon(Icons.chevron_right_rounded, color: AppTheme.textMuted, size: 20),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Most used apps header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  'Most used apps',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
                ),
                Text(
                  'November 25, 2026',
                  style: TextStyle(fontSize: 11, color: AppTheme.textMuted),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // App list
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _appsList.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final app = _appsList[index];
                return _buildAppItem(app);
              },
            ),

            const SizedBox(height: 14),
            // Show all apps button
            Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: const Color(0xFF22253B),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.layers_outlined, size: 18, color: AppTheme.textSecondary),
                  SizedBox(width: 8),
                  Text('Show all apps', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppTheme.textPrimary)),
                  SizedBox(width: 4),
                  Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textSecondary, size: 18),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabPill({required String label, required bool isSelected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF2B2F48) : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: isSelected ? AppTheme.textPrimary : AppTheme.textSecondary,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBar(String day, double heightFraction, bool isHighlighted) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 14,
          height: 90 * heightFraction + (heightFraction > 0 ? 6 : 2),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isHighlighted
                  ? [const Color(0xFFB0A4FF), const Color(0xFF5D50C7)]
                  : [const Color(0xFF9182F7), const Color(0xFF3E3875)],
            ),
            borderRadius: BorderRadius.circular(6),
            boxShadow: isHighlighted
                ? [BoxShadow(color: const Color(0xFF9182F7).withOpacity(0.4), blurRadius: 10, spreadRadius: 1)]
                : null,
          ),
        ),
        const SizedBox(height: 8),
        Text(day, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
      ],
    );
  }

  Widget _buildAppItem(AppUsageItem app) {
    return GestureDetector(
      onTap: () {
        if (app.appName == 'YouTube') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const AppRestrictionsScreen()));
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.03)),
        ),
        child: Row(
          children: [
            _getAppIcon(app),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    app.appName,
                    style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    app.formattedDuration,
                    style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            const Icon(Icons.timer_outlined, size: 18, color: AppTheme.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _getAppIcon(AppUsageItem app) {
    if (app.appName == 'YouTube') {
      return Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: const Color(0xFFFF0000),
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24),
      );
    }

    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Icon(Icons.android, size: 20, color: AppTheme.textSecondary),
    );
  }
}
