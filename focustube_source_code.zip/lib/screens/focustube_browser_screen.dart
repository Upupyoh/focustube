import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';
import '../services/filter_service.dart';
import '../theme/app_theme.dart';
import 'channel_blocker_screen.dart';

class FocusTubeBrowserScreen extends StatefulWidget {
  const FocusTubeBrowserScreen({Key? key}) : super(key: key);

  @override
  State<FocusTubeBrowserScreen> createState() => _FocusTubeBrowserScreenState();
}

class _FocusTubeBrowserScreenState extends State<FocusTubeBrowserScreen> {
  InAppWebViewController? _webViewController;
  double _progress = 0;
  bool _isShieldActive = true;

  void _showBlockedSearchDialog(String term) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgCardElevated,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: const [
            Icon(Icons.block_rounded, color: AppTheme.danger, size: 24),
            SizedBox(width: 8),
            Text('সার্চ ব্লক করা হয়েছে!', style: TextStyle(fontSize: 16)),
          ],
        ),
        content: Text(
          '"$term" চ্যানেল বা বিষয়টি FocusTube ব্লকলিস্টে রয়েছে। তাই এই সার্চ ফলাফল প্রদর্শিত হবে না।',
          style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _webViewController?.loadUrl(urlRequest: URLRequest(url: WebUri('https://m.youtube.com')));
            },
            child: const Text('হোম ফিডে ফিরে যান', style: TextStyle(color: AppTheme.accentPurpleLight, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filterService = Provider.of<FilterService>(context);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            const Icon(Icons.play_arrow_rounded, color: Colors.red, size: 28),
            const SizedBox(width: 6),
            const Text(
              'FocusTube',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const Spacer(),
            // Shield Status Badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _isShieldActive ? AppTheme.accentPurpleBg : Colors.grey.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: _isShieldActive ? AppTheme.accentPurple : Colors.grey,
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _isShieldActive ? Icons.shield_rounded : Icons.shield_outlined,
                    size: 14,
                    color: _isShieldActive ? AppTheme.accentPurpleLight : Colors.grey,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _isShieldActive ? 'Shield Active' : 'Off',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: _isShieldActive ? AppTheme.accentPurpleLight : Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.tune_rounded, color: Colors.white70, size: 20),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ChannelBlockerScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          InAppWebView(
            initialUrlRequest: URLRequest(
              url: WebUri('https://m.youtube.com'),
            ),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              domStorageEnabled: true,
              mediaPlaybackRequiresUserGesture: false,
              useShouldOverrideUrlLoading: true,
              userAgent: 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            ),
            onWebViewCreated: (controller) {
              _webViewController = controller;
            },
            shouldOverrideUrlLoading: (controller, navigationAction) async {
              final uri = navigationAction.request.url;
              if (uri != null && _isShieldActive) {
                final queryParam = uri.queryParameters['search_query'];
                if (queryParam != null && filterService.isQueryBlocked(queryParam)) {
                  _showBlockedSearchDialog(queryParam);
                  return NavigationActionPolicy.CANCEL; // সার্চ নেভিগেশন পুরোপুরি আটকে দেওয়া
                }
              }
              return NavigationActionPolicy.ALLOW;
            },
            onLoadStart: (controller, url) {
              setState(() => _progress = 0.1);
              if (url != null && _isShieldActive) {
                final queryParam = url.queryParameters['search_query'];
                if (queryParam != null && filterService.isQueryBlocked(queryParam)) {
                  _showBlockedSearchDialog(queryParam);
                }
              }
            },
            onProgressChanged: (controller, progress) {
              setState(() => _progress = progress / 100);
            },
            onLoadStop: (controller, url) async {
              setState(() => _progress = 1.0);
              if (_isShieldActive) {
                final script = filterService.generateYouTubeShieldInjectionScript();
                await controller.evaluateJavascript(source: script);
              }
            },
          ),
          if (_progress < 1.0)
            LinearProgressIndicator(
              value: _progress,
              backgroundColor: Colors.transparent,
              valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.accentPurple),
            ),
        ],
      ),
    );
  }
}
