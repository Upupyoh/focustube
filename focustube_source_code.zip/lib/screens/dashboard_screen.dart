import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/filter_service.dart';
import '../theme/app_theme.dart';
import 'statistics_screen.dart';
import 'app_restrictions_screen.dart';
import 'channel_blocker_screen.dart';
import 'thumbnail_filter_screen.dart';
import 'focustube_browser_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final filterService = Provider.of<FilterService>(context);

    return Scaffold(
      backgroundColor: AppTheme.bgMain,
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Action Icons (Grid & Settings)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: () {},
                        icon: const Icon(Icons.grid_view_rounded, color: AppTheme.textSecondary),
                      ),
                      IconButton(
                        onPressed: () => _showPinDialog(context),
                        icon: const Icon(Icons.settings_outlined, color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),

                  // Greetings
                  const Row(
                    children: [
                      Text('👋 ', style: TextStyle(fontSize: 16)),
                      Text(
                        'Welcome back,',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'FocusTube',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimary,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Stats Row (Screen Time & Focus Today)
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatCard(
                          icon: Icons.phone_android_rounded,
                          title: 'Screen time',
                          value: '1h 5m',
                          badgeText: '72% ▼',
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const StatisticsScreen()),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildStatCard(
                          icon: Icons.track_changes_rounded,
                          title: 'Focus today',
                          value: '0s',
                          badgeText: '0% ▲',
                          onTap: () {},
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Glance Card
                  _buildGlanceCard(),
                  const SizedBox(height: 14),

                  // Parental Controls / Invincible Mode
                  _buildParentalControlsCard(context),
                  const SizedBox(height: 22),

                  // Restrictions Section
                  _buildSectionHeader('Restrictions'),
                  const SizedBox(height: 10),

                  _buildActionCard(
                    icon: Icons.apps_rounded,
                    title: 'Apps blocking',
                    subtitle: 'Limit apps in multiple ways.',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const AppRestrictionsScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.smart_display_rounded,
                    title: 'YouTube Channel & Category Filter',
                    subtitle: 'Block unwanted channels & video types.',
                    badgeCount: filterService.blockedChannels.length,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ChannelBlockerScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.image_search_rounded,
                    title: 'Thumbnail Blur & Detection',
                    subtitle: 'Upload samples & blur clickbait/adult images.',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ThumbnailFilterScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.video_collection_outlined,
                    title: 'Shorts blocking',
                    subtitle: 'Limit short content on YouTube & other apps.',
                    trailingWidget: Switch(
                      value: filterService.isShortsBlocked,
                      activeColor: AppTheme.accentPurple,
                      onChanged: (val) {
                        filterService.toggleShortsBlocking(val);
                      },
                    ),
                    onTap: () {},
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.public_rounded,
                    title: 'Websites blocking',
                    subtitle: 'Limit adult and custom websites.',
                    onTap: () {},
                  ),
                  const SizedBox(height: 24),

                  // Productivity Section
                  _buildSectionHeader('Productivity'),
                  const SizedBox(height: 10),

                  _buildActionCard(
                    icon: Icons.coffee_rounded,
                    title: 'Habits',
                    subtitle: 'Build better habits and track them.',
                    onTap: () {},
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.checklist_rounded,
                    title: 'Tasks and todos',
                    subtitle: 'Plan your future with tasks and todos.',
                    onTap: () {},
                  ),
                  const SizedBox(height: 8),

                  _buildActionCard(
                    icon: Icons.note_alt_outlined,
                    title: 'Notes and lists',
                    subtitle: 'Capture thoughts, checklists, or ideas.',
                    onTap: () {},
                  ),
                  const SizedBox(height: 24),

                  // Tips & Tricks Section
                  _buildSectionHeader('Tips & Tricks'),
                  const SizedBox(height: 10),

                  _buildTipCard(
                    sparkleColor: const Color(0xFFFF5263),
                    text: 'Want to track focus sessions? View timeline to see your focus journey.',
                  ),
                  const SizedBox(height: 8),
                  _buildTipCard(
                    sparkleColor: const Color(0xFFF53D74),
                    text: 'Distracted by social apps? Block short content on Instagram, YouTube, etc., to stay focused.',
                  ),
                  const SizedBox(height: 8),
                  _buildTipCard(
                    sparkleColor: const Color(0xFFBA54FC),
                    text: 'Need a break? Use 3 Emergency Passes daily to temporarily unblock apps for 5 minutes.',
                  ),
                  const SizedBox(height: 8),
                  _buildTipCard(
                    sparkleColor: const Color(0xFF875FFC),
                    text: 'Family protection: FocusTube auto-blurs unwanted thumbnails so others using your phone will never see or click sensitive content.',
                  ),

                  const SizedBox(height: 30),
                  // Footer Branding
                  Center(
                    child: Column(
                      children: [
                        const Text(
                          'Protected with ❤️ by FocusTube',
                          style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.code, size: 16, color: AppTheme.textMuted),
                            SizedBox(width: 14),
                            Icon(Icons.coffee, size: 16, color: AppTheme.textMuted),
                            SizedBox(width: 14),
                            Icon(Icons.camera_alt_outlined, size: 16, color: AppTheme.textMuted),
                            SizedBox(width: 14),
                            Icon(Icons.send_rounded, size: 16, color: AppTheme.textMuted),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Sticky Bottom Button "Focus now"
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      AppTheme.bgMain.withOpacity(0.0),
                      AppTheme.bgMain.withOpacity(0.9),
                      AppTheme.bgMain,
                    ],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const FocusTubeBrowserScreen()),
                        );
                      },
                      icon: const Icon(Icons.shield_outlined, color: Color(0xFF171A28)),
                      label: const Text(
                        'Focus now',
                        style: TextStyle(
                          color: Color(0xFF171A28),
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.accentBtnFocus,
                        elevation: 4,
                        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required String badgeText,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 116,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(0.04)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(icon, size: 20, color: AppTheme.accentPurpleLight),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurpleBg,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    badgeText,
                    style: const TextStyle(
                      color: AppTheme.accentPurpleLight,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlanceCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: const [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Glance',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
              ),
              SizedBox(height: 2),
              Text(
                'Take a quick glance at your usage.',
                style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              ),
            ],
          ),
          Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textMuted),
        ],
      ),
    );
  }

  Widget _buildParentalControlsCard(BuildContext context) {
    return GestureDetector(
      onTap: () => _showPinDialog(context),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF22263C), Color(0xFF171827)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.accentPurple.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: AppTheme.accentPurpleBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.shield_outlined, color: AppTheme.accentPurpleLight, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Parental controls',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Invincible mode and tamper protection.',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppTheme.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.bold,
        color: AppTheme.accentPurpleLight,
        letterSpacing: 0.3,
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    int? badgeCount,
    Widget? trailingWidget,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(0.03)),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 20, color: AppTheme.textSecondary),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            if (badgeCount != null && badgeCount > 0)
              Container(
                margin: const EdgeInsets.only(right: 6),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppTheme.accentPurple,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '$badgeCount',
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                ),
              ),
            trailingWidget ?? const Icon(Icons.chevron_right_rounded, color: AppTheme.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _buildTipCard({required Color sparkleColor, required String text}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.03)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.auto_awesome, size: 18, color: sparkleColor),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }

  void _showPinDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: AppTheme.bgCardElevated,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('🛡️ Parental Protection PIN', style: TextStyle(fontSize: 18)),
          content: const Text(
            'অন্যান্য ব্যবহারকারীদের চ্যানেল ব্লকিং বা সেটিংস পরিবর্তন করা থেকে বিরত রাখতে মাস্টার পিন দিয়ে লক করা হয়েছে।',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('ঠিক আছে', style: TextStyle(color: AppTheme.accentPurpleLight)),
            ),
          ],
        );
      },
    );
  }
}
