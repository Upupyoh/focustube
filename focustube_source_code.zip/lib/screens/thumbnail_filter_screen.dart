import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/filter_service.dart';
import '../theme/app_theme.dart';

class ThumbnailFilterScreen extends StatefulWidget {
  const ThumbnailFilterScreen({Key? key}) : super(key: key);

  @override
  State<ThumbnailFilterScreen> createState() => _ThumbnailFilterScreenState();
}

class _ThumbnailFilterScreenState extends State<ThumbnailFilterScreen> {
  bool _previewBlurred = true;

  @override
  Widget build(BuildContext context) {
    final filterService = Provider.of<FilterService>(context);

    return Scaffold(
      backgroundColor: AppTheme.bgMain,
      appBar: AppBar(
        title: const Text('Thumbnail Blur & Detection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: AppTheme.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Upload Sample Thumbnail Box
            GestureDetector(
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('রেফারেন্স থাম্বনেল আপলোড সফল! অন-ডিভাইস AI ক্যাটাগরি ডিটেকশন কনফিগার হয়েছে।'),
                    backgroundColor: AppTheme.accentPurple,
                  ),
                );
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: AppTheme.accentPurple.withOpacity(0.4),
                    style: BorderStyle.solid,
                    width: 1.5,
                  ),
                ),
                child: Column(
                  children: const [
                    Icon(Icons.cloud_upload_outlined, color: AppTheme.accentPurpleLight, size: 40),
                    SizedBox(height: 10),
                    Text(
                      'রেফারেন্স থাম্বনেল আপলোড করুন',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'যে ধরনের থাম্বনেল আপনি পছন্দ করেন না, তার একটি উদাহরণ দিলে FocusTube অনুরূপ সব ভিডিও ডিটেক্ট করবে।',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: AppTheme.textSecondary, height: 1.4),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Live Blur Effect Preview Card
            const Text(
              'লাইভ প্রিভিউ (Live Blur Preview)',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
            ),
            const SizedBox(height: 10),

            Container(
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white.withOpacity(0.04)),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      // Sample thumbnail image
                      Image.network(
                        'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          height: 180,
                          color: const Color(0xFF222538),
                          alignment: Alignment.center,
                          child: const Icon(Icons.image, size: 50, color: AppTheme.textMuted),
                        ),
                      ),
                      // Dynamic blur overlay
                      if (_previewBlurred)
                        Positioned.fill(
                          child: BackdropFilter(
                            filter: ImageFilter.blur(
                              sigmaX: filterService.blurIntensity,
                              sigmaY: filterService.blurIntensity,
                            ),
                            child: Container(
                              color: Colors.black.withOpacity(0.4),
                              alignment: Alignment.center,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.visibility_off_rounded, color: AppTheme.warning, size: 28),
                                  const SizedBox(height: 6),
                                  const Text(
                                    '🛡️ Thumbnail Shielded',
                                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                                  ),
                                  const SizedBox(height: 2),
                                  const Text(
                                    'ক্লিক প্রতিরোধে ব্লার করা হয়েছে',
                                    style: TextStyle(color: Colors.white70, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'থাম্বনেল ব্লার টেস্ট করুন:',
                          style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
                        ),
                        TextButton(
                          onPressed: () => setState(() => _previewBlurred = !_previewBlurred),
                          child: Text(
                            _previewBlurred ? 'ব্লার সরান (Test)' : 'ব্লার কার্যকর করুন',
                            style: const TextStyle(color: AppTheme.accentPurpleLight, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Blur Intensity Slider
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'ব্লার করার মাত্রা (Blur Intensity)',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.accentPurpleLight),
                ),
                Text(
                  '${filterService.blurIntensity.toInt()} px',
                  style: const TextStyle(color: AppTheme.accentPurpleLight, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Slider(
              value: filterService.blurIntensity,
              min: 5,
              max: 35,
              divisions: 6,
              activeColor: AppTheme.accentPurple,
              inactiveColor: AppTheme.bgCardHover,
              onChanged: (val) {
                filterService.setBlurIntensity(val);
              },
            ),
            const SizedBox(height: 18),

            // Protection Strategy Radio / Info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'কেন থাম্বনেল ব্লার জরুরি?',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'ক্লিকবেইট বা আকর্ষণীয় অথচ অনুপযুক্ত থাম্বনেলে বাচ্চারা বা পরিবারের অন্যরা যাতে ভুলবশত ক্লিক করে না ফেলে, সেজন্য FocusTube থাম্বনেলে ব্লার ফিল্টার বসায় এবং ক্লিক সাময়িকভাবে ডিজেবল করে দেয়।',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary, height: 1.45),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
