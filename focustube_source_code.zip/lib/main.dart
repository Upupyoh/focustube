import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/filter_service.dart';
import 'theme/app_theme.dart';
import 'screens/dashboard_screen.dart';
import 'screens/statistics_screen.dart';
import 'screens/app_restrictions_screen.dart';
import 'screens/channel_blocker_screen.dart';
import 'screens/thumbnail_filter_screen.dart';
import 'screens/focustube_browser_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // স্ট্যাটাস বার ও নেভিগেশন বার ডার্ক মোডে সেট করা
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppTheme.bgMain,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FilterService()),
      ],
      child: const FocusTubeApp(),
    ),
  );
}

class FocusTubeApp extends StatelessWidget {
  const FocusTubeApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FocusTube',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      initialRoute: '/',
      routes: {
        '/': (context) => const DashboardScreen(),
        '/stats': (context) => const StatisticsScreen(),
        '/yt_restrictions': (context) => const AppRestrictionsScreen(),
        '/channel_blocker': (context) => const ChannelBlockerScreen(),
        '/thumbnail_filter': (context) => const ThumbnailFilterScreen(),
        '/browser': (context) => const FocusTubeBrowserScreen(),
      },
    );
  }
}
