import 'package:flutter/material.dart';

class AppTheme {
  // স্ক্রিনশট থেকে এক্সট্রাক্ট করা কালার প্যালেট
  static const Color bgMain = Color(0xFF0C0D14);
  static const Color bgCard = Color(0xFF161824);
  static const Color bgCardHover = Color(0xFF1E2030);
  static const Color bgCardElevated = Color(0xFF23263B);

  static const Color accentPurple = Color(0xFF7461E8);
  static const Color accentPurpleLight = Color(0xFFA396FF);
  static const Color accentPurpleBg = Color(0x287461E8);
  static const Color accentBtnFocus = Color(0xFFC3CBFE);

  static const Color textPrimary = Color(0xFFF0F2F8);
  static const Color textSecondary = Color(0xFF9096AB);
  static const Color textMuted = Color(0xFF5E647B);
  static const Color borderSubtle = Color(0xFF242738);

  static const Color danger = Color(0xFFFF5263);
  static const Color warning = Color(0xFFFFB444);
  static const Color success = Color(0xFF38D39F);

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bgMain,
      primaryColor: accentPurple,
      cardColor: bgCard,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: bgMain,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: textPrimary,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
      colorScheme: const ColorScheme.dark(
        primary: accentPurple,
        secondary: accentPurpleLight,
        surface: bgCard,
        error: danger,
      ),
    );
  }
}
