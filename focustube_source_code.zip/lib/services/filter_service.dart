import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/filter_models.dart';

class FilterService extends ChangeNotifier {
  static const String _prefChannelsKey = 'focustube_blocked_channels';
  static const String _prefCategoriesKey = 'focustube_category_rules';
  static const String _prefBlurIntensityKey = 'focustube_blur_intensity';
  static const String _prefPinKey = 'focustube_parental_pin';
  static const String _prefShortsBlockedKey = 'focustube_block_shorts';
  static const String _prefSearchShieldKey = 'focustube_search_shield';

  List<BlockedChannel> _blockedChannels = [];
  List<CategoryFilterRule> _categoryRules = [];
  double _blurIntensity = 20.0;
  String? _masterPin = "1234";
  bool _isShortsBlocked = true;
  bool _isSearchShieldEnabled = true;

  List<BlockedChannel> get blockedChannels => _blockedChannels;
  List<CategoryFilterRule> get categoryRules => _categoryRules;
  double get blurIntensity => _blurIntensity;
  bool get isShortsBlocked => _isShortsBlocked;
  bool get isSearchShieldEnabled => _isSearchShieldEnabled;

  FilterService() {
    _initDefaults();
    _loadFromStorage();
  }

  void _initDefaults() {
    _blockedChannels = [
      BlockedChannel(id: '1', name: 'Drama Daily', reason: 'Unwanted Gossip', createdAt: DateTime.now()),
      BlockedChannel(id: '2', name: 'Viral Sensations', reason: 'Extreme Clickbait', createdAt: DateTime.now()),
      BlockedChannel(id: '3', name: 'Scary Pranks TV', reason: 'Inappropriate for family', createdAt: DateTime.now()),
    ];

    _categoryRules = [
      CategoryFilterRule(
        id: 'cat_sensitive',
        categoryName: 'Adult & Sensitive Content',
        isEnabled: true,
        blurOnly: true,
        keywords: ['18+', 'nsfw', 'adult', 'hot', 'viral scandal', 'leak'],
      ),
      CategoryFilterRule(
        id: 'cat_clickbait',
        categoryName: 'Sensational Clickbait & Gossip',
        isEnabled: true,
        blurOnly: true,
        keywords: ['shocking', 'unbelievable', 'you won\'t believe', 'secret exposed', 'drama'],
      ),
    ];
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final channelsJson = prefs.getString(_prefChannelsKey);
      if (channelsJson != null) {
        final List decoded = jsonDecode(channelsJson);
        _blockedChannels = decoded.map((e) => BlockedChannel.fromMap(e)).toList();
      }

      final categoriesJson = prefs.getString(_prefCategoriesKey);
      if (categoriesJson != null) {
        final List decoded = jsonDecode(categoriesJson);
        _categoryRules = decoded.map((e) => CategoryFilterRule.fromMap(e)).toList();
      }

      _blurIntensity = prefs.getDouble(_prefBlurIntensityKey) ?? 20.0;
      _masterPin = prefs.getString(_prefPinKey) ?? "1234";
      _isShortsBlocked = prefs.getBool(_prefShortsBlockedKey) ?? true;
      _isSearchShieldEnabled = prefs.getBool(_prefSearchShieldKey) ?? true;
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading filter rules: $e');
    }
  }

  Future<void> saveRules() async {
    final prefs = await SharedPreferences.getInstance();
    final channelsEncoded = jsonEncode(_blockedChannels.map((c) => c.toMap()).toList());
    await prefs.setString(_prefChannelsKey, channelsEncoded);

    final categoriesEncoded = jsonEncode(_categoryRules.map((c) => c.toMap()).toList());
    await prefs.setString(_prefCategoriesKey, categoriesEncoded);

    await prefs.setDouble(_prefBlurIntensityKey, _blurIntensity);
    await prefs.setBool(_prefShortsBlockedKey, _isShortsBlocked);
    await prefs.setBool(_prefSearchShieldKey, _isSearchShieldEnabled);
    notifyListeners();
  }

  void addBlockedChannel(String name, {String reason = 'User Blocked'}) {
    if (name.trim().isEmpty) return;
    final exists = _blockedChannels.any((c) => c.name.toLowerCase() == name.trim().toLowerCase());
    if (!exists) {
      _blockedChannels.add(
        BlockedChannel(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          name: name.trim(),
          reason: reason,
          createdAt: DateTime.now(),
        ),
      );
      saveRules();
    }
  }

  void removeBlockedChannel(String id) {
    _blockedChannels.removeWhere((c) => c.id == id);
    saveRules();
  }

  void toggleCategoryRule(String categoryId, bool enabled) {
    final index = _categoryRules.indexWhere((r) => r.id == categoryId);
    if (index != -1) {
      _categoryRules[index] = _categoryRules[index].copyWith(isEnabled: enabled);
      saveRules();
    }
  }

  void setBlurIntensity(double value) {
    _blurIntensity = value;
    saveRules();
  }

  void toggleShortsBlocking(bool value) {
    _isShortsBlocked = value;
    saveRules();
  }

  void toggleSearchShield(bool value) {
    _isSearchShieldEnabled = value;
    saveRules();
  }

  bool isQueryBlocked(String query) {
    if (!_isSearchShieldEnabled || query.trim().isEmpty) return false;
    final cleanQuery = query.toLowerCase().trim();

    // চেক করুন ব্লকলিস্টের কোনো চ্যানেলের সাথে মিলে কি না
    for (final channel in _blockedChannels) {
      if (cleanQuery.contains(channel.name.toLowerCase())) {
        return true;
      }
    }

    // চেক করুন কোনো অ্যাক্টিভ ক্যাটাগরি কিওয়ার্ডের সাথে মিলে কি না
    for (final rule in _categoryRules) {
      if (rule.isEnabled) {
        for (final kw in rule.keywords) {
          if (cleanQuery.contains(kw.toLowerCase())) {
            return true;
          }
        }
      }
    }
    return false;
  }

  /// সম্পূর্ণ শিল্ডিং স্ক্রিপ্ট (Home Feed + Real-time Search Results + Suggestions)
  String generateYouTubeShieldInjectionScript() {
    final blockedListJson = jsonEncode(_blockedChannels.map((c) => c.name.toLowerCase()).toList());
    final activeCategoryKeywords = <String>[];
    for (final rule in _categoryRules) {
      if (rule.isEnabled) {
        activeCategoryKeywords.addAll(rule.keywords.map((k) => k.toLowerCase()));
      }
    }
    final keywordsJson = jsonEncode(activeCategoryKeywords);

    return """
    (function() {
      const blockedChannels = $blockedListJson;
      const blockedKeywords = $keywordsJson;
      const blurPx = ${_blurIntensity.toInt()};
      const blockShorts = $_isShortsBlocked;
      const searchShield = $_isSearchShieldEnabled;

      // CSS ইনজেকশন
      const style = document.createElement('style');
      style.innerHTML = `
        .focustube-blurred-thumb {
          filter: blur(\${blurPx}px) !important;
          pointer-events: none !important;
          transition: filter 0.3s ease !important;
        }
        .focustube-shield-badge {
          position: absolute;
          top: 8px;
          left: 8px;
          background: rgba(116, 97, 232, 0.95);
          color: white;
          padding: 3px 7px;
          font-size: 10px;
          font-weight: bold;
          border-radius: 4px;
          z-index: 10;
        }
        .focustube-search-blocked-msg {
          padding: 20px;
          margin: 15px;
          background: #1b1728;
          border: 1px solid #ff5263;
          border-radius: 12px;
          text-align: center;
          color: #fff;
          font-family: sans-serif;
        }
      `;
      document.head.appendChild(style);

      function sanitizeDOM() {
        // ১. শর্টস সম্পূর্ণ বাদ দেওয়া
        if (blockShorts) {
          const shortsElements = document.querySelectorAll('ytm-reel-shelf-renderer, ytm-pivot-bar-item-renderer[tab-content-id="shorts"], ytd-reel-shelf-renderer, [aria-label*="Shorts"]');
          shortsElements.forEach(el => el.remove());
        }

        // ২. সার্চ কুয়েরি ও ইউআরএল ফিল্টারিং
        if (searchShield && window.location.href.includes('search_query=')) {
          const urlParams = new URLSearchParams(window.location.search);
          const currentQuery = (urlParams.get('search_query') || '').toLowerCase();

          for (let name of blockedChannels) {
            if (currentQuery.includes(name)) {
              const resultsSection = document.querySelector('ytm-search, #contents, .results');
              if (resultsSection && !document.querySelector('.focustube-search-blocked-msg')) {
                resultsSection.innerHTML = `
                  <div class="focustube-search-blocked-msg">
                    <h3 style="color:#ff5263; margin-bottom:8px;">🚫 সার্চ ফলাফল প্রদর্শিত হবে না</h3>
                    <p style="font-size:12px; color:#bbb;">FocusTube সুরক্ষার কারণে এই চ্যানেল বা বিষয়ের সার্চ ফলাফল সম্পূর্ণ ব্লক করা হয়েছে।</p>
                  </div>
                `;
              }
              return;
            }
          }
        }

        // ৩. সার্চ অটো-সাজেশন রিমুভ (Search suggestions filtering)
        const suggestions = document.querySelectorAll('.ytm-search-suggestion, .sbdd_b li, [role="option"]');
        suggestions.forEach(item => {
          const text = (item.innerText || '').toLowerCase();
          for (let name of blockedChannels) {
            if (text.includes(name)) {
              item.remove();
            }
          }
        });

        // ৪. ভিডিও ও চ্যানেল কার্ড স্ক্যান (ফিড এবং সার্চ রেজাল্ট উভয় জায়গাতেই)
        const allCards = document.querySelectorAll('ytm-video-with-context-renderer, ytm-compact-video-renderer, ytm-channel-renderer, ytm-compact-channel-renderer, ytd-video-renderer, ytd-channel-renderer, yt-lockup-view-model');

        allCards.forEach(card => {
          if (card.dataset.focustubeChecked) return;

          const textContent = (card.innerText || '').toLowerCase();
          const channelElem = card.querySelector('.ytm-badge-and-byline-item, .ytd-channel-name, .yt-core-attributed-string, [aria-label*="channel"]');
          const channelName = channelElem ? channelElem.innerText.toLowerCase().trim() : '';

          // ক) চ্যানেল চেক
          let isBlocked = false;
          for (let name of blockedChannels) {
            if (channelName.includes(name) || textContent.includes(name)) {
              isBlocked = true;
              break;
            }
          }

          if (isBlocked) {
            card.remove(); // সার্চ রেজাল্ট বা ফিড থেকে সম্পূর্ণরূপে মুছে ফেলা
            return;
          }

          // খ) কিওয়ার্ড এবং থাম্বনেল ব্লার চেক
          let hasBlockedKw = false;
          for (let kw of blockedKeywords) {
            if (textContent.includes(kw)) {
              hasBlockedKw = true;
              break;
            }
          }

          if (hasBlockedKw) {
            const thumb = card.querySelector('img, .ytm-thumbnail-cover, .ytd-thumbnail');
            if (thumb) {
              thumb.classList.add('focustube-blurred-thumb');
              if (!card.querySelector('.focustube-shield-badge')) {
                const badge = document.createElement('div');
                badge.className = 'focustube-shield-badge';
                badge.innerText = '🛡️ FocusTube Shielded';
                thumb.parentElement.style.position = 'relative';
                thumb.parentElement.appendChild(badge);
              }
            }
          }

          card.dataset.focustubeChecked = "true";
        });
      }

      const observer = new MutationObserver(sanitizeDOM);
      observer.observe(document.body, { childList: true, subtree: true });
      sanitizeDOM();
    })();
    """;
  }
}
