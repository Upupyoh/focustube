import 'dart:convert';

/// মডেল: ব্লক করা চ্যানেল
class BlockedChannel {
  final String id;
  final String name;
  final String? handle;
  final String reason;
  final DateTime createdAt;

  BlockedChannel({
    required this.id,
    required this.name,
    this.handle,
    this.reason = 'User Blocked',
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'handle': handle,
    'reason': reason,
    'createdAt': createdAt.toIso8601String(),
  };

  factory BlockedChannel.fromMap(Map<String, dynamic> map) => BlockedChannel(
    id: map['id'],
    name: map['name'],
    handle: map['handle'],
    reason: map['reason'] ?? 'User Blocked',
    createdAt: DateTime.parse(map['createdAt']),
  );
}

/// মডেল: থাম্বনেল ফিল্টারিং ক্যাটাগরি ও রুল
class CategoryFilterRule {
  final String id;
  final String categoryName;
  final bool isEnabled;
  final bool blurOnly; // true = blur thumbnail, false = completely hide card
  final List<String> keywords;

  CategoryFilterRule({
    required this.id,
    required this.categoryName,
    required this.isEnabled,
    this.blurOnly = true,
    required this.keywords,
  });

  CategoryFilterRule copyWith({
    bool? isEnabled,
    bool? blurOnly,
    List<String>? keywords,
  }) {
    return CategoryFilterRule(
      id: id,
      categoryName: categoryName,
      isEnabled: isEnabled ?? this.isEnabled,
      blurOnly: blurOnly ?? this.blurOnly,
      keywords: keywords ?? this.keywords,
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'categoryName': categoryName,
    'isEnabled': isEnabled,
    'blurOnly': blurOnly,
    'keywords': keywords,
  };

  factory CategoryFilterRule.fromMap(Map<String, dynamic> map) => CategoryFilterRule(
    id: map['id'],
    categoryName: map['categoryName'],
    isEnabled: map['isEnabled'] ?? true,
    blurOnly: map['blurOnly'] ?? true,
    keywords: List<String>.from(map['keywords'] ?? []),
  );
}

/// মডেল: অ্যাপ ইউসেজ ডাটা
class AppUsageItem {
  final String appName;
  final String packageName;
  final int usageMinutes;
  final int usageSeconds;
  final String iconKey;

  AppUsageItem({
    required this.appName,
    required this.packageName,
    required this.usageMinutes,
    this.usageSeconds = 0,
    required this.iconKey,
  });

  String get formattedDuration {
    if (usageMinutes > 0 && usageSeconds > 0) {
      return '$usageMinutes minutes, $usageSeconds seconds';
    } else if (usageMinutes > 0) {
      return '$usageMinutes minutes';
    } else {
      return '$usageSeconds seconds';
    }
  }
}
